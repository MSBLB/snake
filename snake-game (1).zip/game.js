document.addEventListener('DOMContentLoaded', () => {
    // 获取DOM元素
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const scoreElement = document.getElementById('score');
    const highScoreElement = document.getElementById('highScore');
    const startBtn = document.getElementById('startBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const restartBtn = document.getElementById('restartBtn');
    const gameOverElement = document.getElementById('gameOver');
    const finalScoreElement = document.getElementById('finalScore');
    const bossChallengeElement = document.getElementById('bossChallenge');
    const bossTimerElement = document.getElementById('bossTimer');
    const bossHealthBarElement = document.getElementById('bossHealthBar');
    const bossMessageElement = document.getElementById('bossMessage');
    const powerupActiveElement = document.getElementById('powerupActive');
    const powerupTimerElement = document.getElementById('powerupTimer');
    const classicModeTab = document.getElementById('classicModeTab');
    const levelModeTab = document.getElementById('levelModeTab');
    const classicModeInfo = document.getElementById('classicModeInfo');
    const levelModeInfo = document.getElementById('levelModeInfo');
    const currentLevelElement = document.getElementById('currentLevel');
    const levelGoalElement = document.getElementById('levelGoal');
    const levelProgressElement = document.getElementById('levelProgress');
    const levelProgressBarElement = document.getElementById('levelProgressBar');
    const startLevelBtn = document.getElementById('startLevelBtn');
    const levelCompleteElement = document.getElementById('levelComplete');
    const completedLevelElement = document.getElementById('completedLevel');
    const levelScoreElement = document.getElementById('levelScore');
    const nextLevelBtn = document.getElementById('nextLevelBtn');
    const restartLevelBtn = document.getElementById('restartLevelBtn');
    
    // 移动设备控制按钮
    const upBtn = document.getElementById('upBtn');
    const downBtn = document.getElementById('downBtn');
    const leftBtn = document.getElementById('leftBtn');
    const rightBtn = document.getElementById('rightBtn');

    // 设置画布尺寸
    function resizeCanvas() {
        // 保持画布为正方形，最大宽度为600px
        const size = Math.min(
            Math.floor(Math.min(window.innerWidth, 600) / 20) * 20,
            Math.floor(Math.min(window.innerHeight - 400, 600) / 20) * 20
        );
        canvas.width = size;
        canvas.height = size;
    }
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // 游戏配置
    let snake = [];
    let food = {};
    let boss = null;
    let powerup = null;
    let direction = '';
    let nextDirection = '';
    let score = 0;
    let highScore = localStorage.getItem('snakeHighScore') || 0;
    let gameSpeed = 150;
    let gameInterval;
    let isPaused = false;
    let isGameOver = true;
    let isBossActive = false;
    let bossHealth = 100;
    let bossTimer = 30; // 30秒挑战时间
    let bossInterval;
    let powerupActive = false;
    let powerupType = '';
    let powerupTimer = 0;
    let powerupInterval;
    let gridSize = 20;
    let bossSpawnThreshold = 100; // 每100分触发一次BOSS
    
    // 关卡模式配置
    let isLevelMode = false;
    let currentLevel = 1;
    let levelGoals = [
        { type: 'score', target: 100 },     // 关卡1：获得100分
        { type: 'length', target: 20 },    // 关卡2：达到20长度
        { type: 'time', target: 60 },      // 关卡3：存活60秒
        { type: 'boss', target: 1 },       // 关卡4：击败BOSS
        { type: 'combo', targets: [       // 关卡5：组合目标
            { type: 'score', target: 200 },
            { type: 'length', target: 30 }
        ]}
    ];
    let levelStartTime = 0;
    let levelTime = 0;
    let levelTimeInterval;
    let levelProgress = 0;

    // 初始化高分
    highScoreElement.textContent = highScore;

    // 初始化游戏
    function initGame(mode = 'classic') {
        isLevelMode = mode === 'level';
        
        // 重置游戏状态
        score = 0;
        gameSpeed = 150;
        isPaused = false;
        isGameOver = false;
        isBossActive = false;
        boss = null;
        bossHealth = 100;
        bossTimer = 30;
        powerup = null;
        powerupActive = false;
        levelProgress = 0;
        
        // 隐藏游戏结束和BOSS挑战画面
        gameOverElement.classList.add('hidden');
        bossChallengeElement.classList.add('hidden');
        powerupActiveElement.classList.add('hidden');
        levelCompleteElement.classList.add('hidden');
        
        // 设置蛇的初始位置和长度
        const center = Math.floor((canvas.width / gridSize) / 2);
        snake = [
            {x: center * gridSize, y: center * gridSize},
            {x: (center - 1) * gridSize, y: center * gridSize},
            {x: (center - 2) * gridSize, y: center * gridSize}
        ];
        
        // 设置初始方向
        direction = 'right';
        nextDirection = 'right';
        
        // 初始化关卡模式数据
        if (isLevelMode) {
            updateLevelDisplay();
            levelStartTime = Date.now();
            
            if (levelTimeInterval) clearInterval(levelTimeInterval);
            if (levelGoals[currentLevel - 1].type === 'time') {
                levelTimeInterval = setInterval(() => {
                    levelTime = Math.floor((Date.now() - levelStartTime) / 1000);
                    updateLevelProgress();
                }, 1000);
            }
        } else {
            scoreElement.textContent = score;
        }
        
        // 生成第一个食物
        generateFood();
        
        // 开始游戏循环
        if (gameInterval) clearInterval(gameInterval);
        gameInterval = setInterval(gameLoop, gameSpeed);
    }

    // 生成食物
    function generateFood() {
        // 随机位置
        const maxPos = canvas.width / gridSize - 1;
        food = {
            x: Math.floor(Math.random() * maxPos) * gridSize,
            y: Math.floor(Math.random() * maxPos) * gridSize
        };
        
        // 确保食物不会出现在蛇身上或BOSS上
        for (let segment of snake) {
            if (segment.x === food.x && segment.y === food.y) {
                generateFood();
                return;
            }
        }
        
        if (boss) {
            if (Math.abs(food.x - boss.x) < gridSize * 2 && Math.abs(food.y - boss.y) < gridSize * 2) {
                generateFood();
                return;
            }
        }
        
        // 有10%的概率生成变形道具而不是普通食物
        if (Math.random() < 0.1 && !powerup && !powerupActive) {
            generatePowerup();
        }
    }
    
    // 生成变形道具
    function generatePowerup() {
        const maxPos = canvas.width / gridSize - 1;
        powerup = {
            x: Math.floor(Math.random() * maxPos) * gridSize,
            y: Math.floor(Math.random() * maxPos) * gridSize,
            type: getRandomPowerupType() // 随机一种道具类型
        };
        
        // 确保道具不会出现在蛇身上或食物、BOSS上
        for (let segment of snake) {
            if (segment.x === powerup.x && segment.y === powerup.y) {
                generatePowerup();
                return;
            }
        }
        
        if (Math.abs(powerup.x - food.x) < gridSize * 2 && Math.abs(powerup.y - food.y) < gridSize * 2) {
            generatePowerup();
            return;
        }
        
        if (boss) {
            if (Math.abs(powerup.x - boss.x) < gridSize * 2 && Math.abs(powerup.y - boss.y) < gridSize * 2) {
                generatePowerup();
                return;
            }
        }
    }
    
    // 获取随机道具类型
    function getRandomPowerupType() {
        const types = ['speed', 'invincible', 'growth', 'phasing'];
        return types[Math.floor(Math.random() * types.length)];
    }
    
    // 激活道具效果
    function activatePowerup() {
        powerupActive = true;
        powerupType = powerup.type;
        powerupTimer = 10; // 10秒效果持续时间
        
        // 根据道具类型应用不同效果
        switch(powerupType) {
            case 'speed':
                // 速度加倍
                clearInterval(gameInterval);
                gameInterval = setInterval(gameLoop, gameSpeed / 2);
                break;
            case 'invincible':
                // 无敌状态
                break;
            case 'growth':
                // 立即增长
                for (let i = 0; i < 5; i++) {
                    const tail = {...snake[snake.length - 1]};
                    snake.push(tail);
                }
                break;
            case 'phasing':
                // 穿墙效果
                break;
        }
        
        // 显示道具激活UI
        powerupActiveElement.classList.remove('hidden');
        powerupTimerElement.textContent = powerupTimer;
        
        // 开始倒计时
        if (powerupInterval) clearInterval(powerupInterval);
        powerupInterval = setInterval(() => {
            powerupTimer--;
            powerupTimerElement.textContent = powerupTimer;
            
            if (powerupTimer <= 0) {
                deactivatePowerup();
            }
        }, 1000);
        
        // 移除道具
        powerup = null;
    }
    
    // 停用道具效果
    function deactivatePowerup() {
        powerupActive = false;
        powerupType = '';
        
        // 恢复正常速度
        if (powerupType === 'speed') {
            clearInterval(gameInterval);
            gameInterval = setInterval(gameLoop, gameSpeed);
        }
        
        // 隐藏道具激活UI
        powerupActiveElement.classList.add('hidden');
        clearInterval(powerupInterval);
    }
    
    // 生成BOSS
    function spawnBoss() {
        isBossActive = true;
        
        // BOSS位置（屏幕边缘）
        const edge = Math.floor(Math.random() * 4); // 0-3: 上、右、下、左
        const maxPos = canvas.width / gridSize - 1;
        
        switch(edge) {
            case 0: // 上
                boss = {
                    x: Math.floor(Math.random() * maxPos) * gridSize,
                    y: 0,
                    direction: 'down',
                    health: 100,
                    size: 5, // BOSS大小（格子数）
                    segments: []
                };
                break;
            case 1: // 右
                boss = {
                    x: canvas.width - gridSize,
                    y: Math.floor(Math.random() * maxPos) * gridSize,
                    direction: 'left',
                    health: 100,
                    size: 5,
                    segments: []
                };
                break;
            case 2: // 下
                boss = {
                    x: Math.floor(Math.random() * maxPos) * gridSize,
                    y: canvas.height - gridSize,
                    direction: 'up',
                    health: 100,
                    size: 5,
                    segments: []
                };
                break;
            case 3: // 左
                boss = {
                    x: 0,
                    y: Math.floor(Math.random() * maxPos) * gridSize,
                    direction: 'right',
                    health: 100,
                    size: 5,
                    segments: []
                };
                break;
        }
        
        // 初始化BOSS的身体部分
        for (let i = 0; i < boss.size; i++) {
            let segmentX = boss.x;
            let segmentY = boss.y;
            
            switch(boss.direction) {
                case 'up':
                    segmentY += i * gridSize;
                    break;
                case 'down':
                    segmentY -= i * gridSize;
                    break;
                case 'left':
                    segmentX += i * gridSize;
                    break;
                case 'right':
                    segmentX -= i * gridSize;
                    break;
            }
            
            boss.segments.push({x: segmentX, y: segmentY});
        }
        
        // 显示BOSS挑战UI
        bossChallengeElement.classList.remove('hidden');
        bossHealthBarElement.style.width = '100%';
        bossTimerElement.textContent = bossTimer;
        
        // 开始BOSS计时器
        if (bossInterval) clearInterval(bossInterval);
        bossInterval = setInterval(() => {
            bossTimer--;
            bossTimerElement.textContent = bossTimer;
            
            if (bossTimer <= 0) {
                endBossChallenge(false);
            }
        }, 1000);
    }
    
    // 更新BOSS位置
    function updateBoss() {
        if (!boss) return;
        
        // BOSS移动逻辑
        const directions = ['up', 'down', 'left', 'right'];
        // 有20%的概率改变方向
        if (Math.random() < 0.2) {
            let newDirection;
            do {
                newDirection = directions[Math.floor(Math.random() * directions.length)];
            } while (
                (newDirection === 'up' && boss.direction === 'down') ||
                (newDirection === 'down' && boss.direction === 'up') ||
                (newDirection === 'left' && boss.direction === 'right') ||
                (newDirection === 'right' && boss.direction === 'left')
            );
            boss.direction = newDirection;
        }
        
        // 移动BOSS头部
        const head = {...boss.segments[0]};
        switch(boss.direction) {
            case 'up':
                head.y -= gridSize;
                break;
            case 'down':
                head.y += gridSize;
                break;
            case 'left':
                head.x -= gridSize;
                break;
            case 'right':
                head.x += gridSize;
                break;
        }
        
        // BOSS边界检查（反弹）
        if (head.x < 0) {
            head.x = 0;
            boss.direction = 'right';
        } else if (head.x >= canvas.width) {
            head.x = canvas.width - gridSize;
            boss.direction = 'left';
        }
        
        if (head.y < 0) {
            head.y = 0;
            boss.direction = 'down';
        } else if (head.y >= canvas.height) {
            head.y = canvas.height - gridSize;
            boss.direction = 'up';
        }
        
        // 更新BOSS身体
        boss.segments.unshift(head);
        boss.segments.pop();
    }
    
    // 结束BOSS挑战
    function endBossChallenge(success) {
        isBossActive = false;
        boss = null;
        bossChallengeElement.classList.add('hidden');
        clearInterval(bossInterval);
        
        if (success) {
            // 挑战成功奖励
            if (isLevelMode && levelGoals[currentLevel - 1].type === 'boss') {
                levelProgress = levelGoals[currentLevel - 1].target;
                checkLevelComplete();
            } else {
                score += 50; // 额外加分
                scoreElement.textContent = score;
            }
            bossMessageElement.textContent = '挑战成功！获得50分奖励！';
            
            // 更新最高分
            if (score > highScore) {
                highScore = score;
                highScoreElement.textContent = highScore;
                localStorage.setItem('snakeHighScore', highScore);
            }
        } else {
            // 挑战失败惩罚
            bossMessageElement.textContent = '挑战失败！';
            
            // 移除蛇的后半部分作为惩罚
            const halfLength = Math.floor(snake.length / 2);
            snake.splice(halfLength);
            
            // 如果蛇太短，游戏结束
            if (snake.length < 1) {
                gameOver();
                return;
            }
        }
        
        // 重置BOSS计时器
        bossTimer = 30;
        
        // 生成新食物
        generateFood();
    }

    // 游戏主循环
    function gameLoop() {
        if (isPaused || isGameOver) return;
        
        // 检查是否应该生成BOSS
        if (!isBossActive && !isLevelMode && score > 0 && score % bossSpawnThreshold === 0) {
            spawnBoss();
            return;
        }
        
        // 检查关卡目标是否需要生成BOSS
        if (isLevelMode && levelGoals[currentLevel - 1].type === 'boss' && !isBossActive && !boss) {
            spawnBoss();
            return;
        }
        
        // 更新方向
        direction = nextDirection;
        
        // 检查是否撞到墙壁（无敌状态下可以穿墙）
        const head = {x: snake[0].x, y: snake[0].y};
        let isWallCollision = false;
        
        switch(direction) {
            case 'up':
                head.y -= gridSize;
                if (head.y < 0) isWallCollision = true;
                break;
            case 'down':
                head.y += gridSize;
                if (head.y >= canvas.height) isWallCollision = true;
                break;
            case 'left':
                head.x -= gridSize;
                if (head.x < 0) isWallCollision = true;
                break;
            case 'right':
                head.x += gridSize;
                if (head.x >= canvas.width) isWallCollision = true;
                break;
        }
        
        // 处理穿墙效果
        if (isWallCollision) {
            if (powerupType === 'phasing') {
                // 穿墙
                if (head.x < 0) head.x = canvas.width - gridSize;
                if (head.x >= canvas.width) head.x = 0;
                if (head.y < 0) head.y = canvas.height - gridSize;
                if (head.y >= canvas.height) head.y = 0;
                isWallCollision = false;
            } else {
                gameOver();
                return;
            }
        }
        
        // 检查是否撞到自己（无敌状态下不会死亡）
        const isSelfCollision = checkSelfCollision(head);
        if (isSelfCollision && !powerupActive) {
            gameOver();
            return;
        }
        
        // 将新头部添加到蛇身
        snake.unshift(head);
        
        // 检查是否吃到食物
        let ateFood = false;
        if (head.x === food.x && head.y === food.y) {
            // 增加分数
            score += 10;
            scoreElement.textContent = score;
            
            // 更新最高分
            if (score > highScore) {
                highScore = score;
                highScoreElement.textContent = highScore;
                localStorage.setItem('snakeHighScore', highScore);
            }
            
            // 加速游戏
            if (!isLevelMode && score % 50 === 0 && gameSpeed > 50) {
                gameSpeed -= 10;
                clearInterval(gameInterval);
                gameInterval = setInterval(gameLoop, gameSpeed);
            }
            
            // 生成新食物
            generateFood();
            ateFood = true;
        }
        
        // 检查是否吃到道具
        if (powerup && head.x === powerup.x && head.y === powerup.y) {
            activatePowerup();
        }
        
        // 检查BOSS碰撞
        if (boss && isBossActive) {
            for (let i = 0; i < boss.segments.length; i++) {
                const bossSegment = boss.segments[i];
                
                // 如果是无敌状态，可以攻击BOSS
                if (powerupType === 'invincible' && Math.abs(head.x - bossSegment.x) < gridSize && Math.abs(head.y - bossSegment.y) < gridSize) {
                    // 伤害BOSS
                    boss.health -= 10;
                    bossHealthBarElement.style.width = `${boss.health}%`;
                    
                    // 从BOSS尾部移除一段
                    if (boss.health > 0 && boss.segments.length > 1) {
                        boss.segments.pop();
                    }
                    
                    // BOSS被击败
                    if (boss.health <= 0) {
                        endBossChallenge(true);
                    }
                    
                    // 移除蛇的头部（模拟攻击后受伤）
                    snake.shift();
                    
                    // 如果蛇太短，游戏结束
                    if (snake.length < 1) {
                        gameOver();
                        return;
                    }
                    
                    return;
                } else if (i === 0 && Math.abs(head.x - bossSegment.x) < gridSize && Math.abs(head.y - bossSegment.y) < gridSize) {
                    // 撞到BOSS头部，游戏结束
                    gameOver();
                    return;
                } else if (Math.abs(head.x - bossSegment.x) < gridSize && Math.abs(head.y - bossSegment.y) < gridSize) {
                    // 撞到BOSS身体，移除蛇的一部分
                    const removeLength = Math.min(5, snake.length - 1);
                    snake.splice(-removeLength);
                    
                    // 如果蛇太短，游戏结束
                    if (snake.length < 1) {
                        gameOver();
                        return;
                    }
                    
                    return;
                }
            }
        }
        
        // 如果没吃到食物，移除尾部
        if (!ateFood) {
            snake.pop();
        }
        
        // 更新BOSS位置
        if (boss && isBossActive) {
            updateBoss();
        }
        
        // 更新关卡进度
        if (isLevelMode) {
            updateLevelProgress();
        }
        
        // 绘制游戏
        drawGame();
    }

    // 检查蛇是否撞到自己
    function checkSelfCollision(head) {
        // 无敌状态下不会撞到自己
        if (powerupType === 'invincible') return false;
        
        for (let i = 1; i < snake.length; i++) {
            if (head.x === snake[i].x && head.y === snake[i].y) {
                return true;
            }
        }
        return false;
    }

    // 绘制游戏
    function drawGame() {
        // 清空画布
        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // 绘制网格（可选）
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        for (let x = 0; x < canvas.width; x += gridSize) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, canvas.height);
            ctx.stroke();
        }
        for (let y = 0; y < canvas.height; y += gridSize) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
        }
        
        // 绘制食物
        ctx.fillStyle = '#ef4444'; // 红色
        ctx.beginPath();
        ctx.arc(
            food.x + gridSize / 2, 
            food.y + gridSize / 2, 
            gridSize / 2 - 1, 
            0, 
            Math.PI * 2
        );
        ctx.fill();
        
        // 绘制变形道具
        if (powerup) {
            ctx.fillStyle = '#f59e0b'; // 黄色
            ctx.beginPath();
            
            // 根据道具类型绘制不同形状
            switch(powerup.type) {
                case 'speed':
                    // 三角形（代表速度）
                    ctx.moveTo(powerup.x + gridSize / 2, powerup.y);
                    ctx.lineTo(powerup.x + gridSize, powerup.y + gridSize);
                    ctx.lineTo(powerup.x, powerup.y + gridSize);
                    ctx.closePath();
                    break;
                case 'invincible':
                    // 圆形（代表无敌）
                    ctx.arc(
                        powerup.x + gridSize / 2, 
                        powerup.y + gridSize / 2, 
                        gridSize / 2 - 1, 
                        0, 
                        Math.PI * 2
                    );
                    break;
                case 'growth':
                    // 正方形（代表增长）
                    ctx.rect(powerup.x, powerup.y, gridSize, gridSize);
                    break;
                case 'phasing':
                    // 星形（代表穿墙）
                    drawStar(ctx, powerup.x + gridSize / 2, powerup.y + gridSize / 2, 5, gridSize / 2 - 1, gridSize / 4);
                    break;
            }
            
            ctx.fill();
        }
        
        // 绘制BOSS
        if (boss && isBossActive) {
            boss.segments.forEach((segment, index) => {
                // BOSS头部
                if (index === 0) {
                    ctx.fillStyle = '#dc2626'; // 深红色
                    ctx.strokeStyle = '#991b1b'; // 更深红色
                    
                    // 绘制BOSS头部
                    ctx.fillRect(segment.x, segment.y, gridSize, gridSize);
                    ctx.strokeRect(segment.x, segment.y, gridSize, gridSize);
                    
                    // BOSS眼睛
                    ctx.fillStyle = 'white';
                    const eyeSize = gridSize / 6;
                    const eyeOffset = gridSize / 3;
                    
                    // 根据方向调整眼睛位置
                    switch(boss.direction) {
                        case 'up':
                            ctx.fillRect(segment.x + eyeOffset, segment.y + eyeOffset, eyeSize, eyeSize);
                            ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + eyeOffset, eyeSize, eyeSize);
                            break;
                        case 'down':
                            ctx.fillRect(segment.x + eyeOffset, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                            ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                            break;
                        case 'left':
                            ctx.fillRect(segment.x + eyeOffset, segment.y + eyeOffset, eyeSize, eyeSize);
                            ctx.fillRect(segment.x + eyeOffset, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                            break;
                        case 'right':
                            ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + eyeOffset, eyeSize, eyeSize);
                            ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                            break;
                    }
                } else {
                    // BOSS身体
                    ctx.fillStyle = '#ef4444'; // 红色
                    ctx.strokeStyle = '#991b1b'; // 更深红色
                    ctx.fillRect(segment.x, segment.y, gridSize, gridSize);
                    ctx.strokeRect(segment.x, segment.y, gridSize, gridSize);
                }
            });
        }
        
        // 绘制蛇
        snake.forEach((segment, index) => {
            // 蛇头和身体使用不同颜色
            if (index === 0) {
                // 蛇头
                if (powerupActive) {
                    // 激活道具时的特殊颜色
                    ctx.fillStyle = getPowerupColor(powerupType);
                    ctx.strokeStyle = '#16a34a';
                } else {
                    ctx.fillStyle = '#22c55e'; // 绿色
                    ctx.strokeStyle = '#16a34a'; // 深绿色
                }
            } else if (index === 1) {
                // 蛇身第一节
                ctx.fillStyle = '#4ade80';
                ctx.strokeStyle = '#16a34a';
            } else if (index === 2) {
                // 蛇身第二节
                ctx.fillStyle = '#86efac';
                ctx.strokeStyle = '#16a34a';
            } else {
                // 其他部分
                ctx.fillStyle = '#dcfce7';
                ctx.strokeStyle = '#16a34a';
            }
            
            // 绘制蛇的身体部分
            ctx.fillRect(segment.x, segment.y, gridSize, gridSize);
            ctx.strokeRect(segment.x, segment.y, gridSize, gridSize);
            
            // 蛇头的眼睛
            if (index === 0) {
                ctx.fillStyle = 'white';
                const eyeSize = gridSize / 6;
                const eyeOffset = gridSize / 3;
                
                // 根据方向调整眼睛位置
                switch(direction) {
                    case 'up':
                        ctx.fillRect(segment.x + eyeOffset, segment.y + eyeOffset, eyeSize, eyeSize);
                        ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + eyeOffset, eyeSize, eyeSize);
                        break;
                    case 'down':
                        ctx.fillRect(segment.x + eyeOffset, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                        ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                        break;
                    case 'left':
                        ctx.fillRect(segment.x + eyeOffset, segment.y + eyeOffset, eyeSize, eyeSize);
                        ctx.fillRect(segment.x + eyeOffset, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                        break;
                    case 'right':
                        ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + eyeOffset, eyeSize, eyeSize);
                        ctx.fillRect(segment.x + gridSize - eyeOffset - eyeSize, segment.y + gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                        break;
                }
            }
        });
    }
    
    // 根据道具类型获取颜色
    function getPowerupColor(type) {
        switch(type) {
            case 'speed':
                return '#3b82f6'; // 蓝色
            case 'invincible':
                return '#8b5cf6'; // 紫色
            case 'growth':
                return '#f97316'; // 橙色
            case 'phasing':
                return '#ec4899'; // 粉色
            default:
                return '#22c55e'; // 绿色
        }
    }
    
    // 绘制星形
    function drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius) {
        let rot = Math.PI / 2 * 3;
        let x = cx;
        let y = cy;
        let step = Math.PI / spikes;
        
        ctx.beginPath();
        ctx.moveTo(cx, cy - outerRadius);
        
        for (let i = 0; i < spikes; i++) {
            x = cx + Math.cos(rot) * outerRadius;
            y = cy + Math.sin(rot) * outerRadius;
            ctx.lineTo(x, y);
            rot += step;
            
            x = cx + Math.cos(rot) * innerRadius;
            y = cy + Math.sin(rot) * innerRadius;
            ctx.lineTo(x, y);
            rot += step;
        }
        
        ctx.lineTo(cx, cy - outerRadius);
        ctx.closePath();
    }

    // 游戏结束
    function gameOver() {
        isGameOver = true;
        clearInterval(gameInterval);
        if (bossInterval) clearInterval(bossInterval);
        if (powerupInterval) clearInterval(powerupInterval);
        if (levelTimeInterval) clearInterval(levelTimeInterval);
        finalScoreElement.textContent = score;
        gameOverElement.classList.remove('hidden');
        
        // 更新按钮状态
        startBtn.disabled = false;
        pauseBtn.disabled = true;
        startLevelBtn.disabled = false;
    }

    // 暂停/继续游戏
    function togglePause() {
        if (isGameOver) return;
        
        isPaused = !isPaused;
        
        if (isPaused) {
            clearInterval(gameInterval);
            if (bossInterval) clearInterval(bossInterval);
            if (powerupInterval) clearInterval(powerupInterval);
            if (levelTimeInterval) clearInterval(levelTimeInterval);
            pauseBtn.innerHTML = '<i class="fa fa-play mr-1"></i> 继续';
        } else {
            gameInterval = setInterval(gameLoop, gameSpeed);
            if (isBossActive) {
                bossInterval = setInterval(() => {
                    bossTimer--;
                    bossTimerElement.textContent = bossTimer;
                    
                    if (bossTimer <= 0) {
                        endBossChallenge(false);
                    }
                }, 1000);
            }
            if (powerupActive) {
                powerupInterval = setInterval(() => {
                    powerupTimer--;
                    powerupTimerElement.textContent = powerupTimer;
                    
                    if (powerupTimer <= 0) {
                        deactivatePowerup();
                    }
                }, 1000);
            }
            if (isLevelMode && levelGoals[currentLevel - 1].type === 'time') {
                levelTimeInterval = setInterval(() => {
                    levelTime = Math.floor((Date.now() - levelStartTime) / 1000);
                    updateLevelProgress();
                }, 1000);
            }
            pauseBtn.innerHTML = '<i class="fa fa-pause mr-1"></i> 暂停';
        }
    }

    // 更新关卡显示
    function updateLevelDisplay() {
        const goal = levelGoals[currentLevel - 1];
        
        if (goal.type === 'combo') {
            levelGoalElement.textContent = `组合目标`;
        } else if (goal.type === 'boss') {
            levelGoalElement.textContent = `击败BOSS`;
        } else {
            const goalText = goal.type === 'score' ? '分' : 
                             goal.type === 'length' ? '长度' : 
                             goal.type === 'time' ? '秒存活' : '';
            levelGoalElement.textContent = `${goal.target}${goalText}`;
        }
        
        currentLevelElement.textContent = currentLevel;
        updateLevelProgress();
    }

    // 更新关卡进度
    function updateLevelProgress() {
        const goal = levelGoals[currentLevel - 1];
        
        if (goal.type === 'score') {
            levelProgress = score;
            levelProgressElement.textContent = score;
        } else if (goal.type === 'length') {
            levelProgress = snake.length;
            levelProgressElement.textContent = snake.length;
        } else if (goal.type === 'time') {
            levelProgress = levelTime;
            levelProgressElement.textContent = `${levelTime}秒`;
        } else if (goal.type === 'boss') {
            // BOSS进度在击败BOSS时更新
            levelProgressElement.textContent = boss ? '战斗中...' : '等待BOSS出现';
        } else if (goal.type === 'combo') {
            // 组合目标
            const subGoals = goal.targets;
            let combinedProgress = 0;
            let combinedTarget = 0;
            let progressText = '';
            
            for (const subGoal of subGoals) {
                let currentValue = 0;
                if (subGoal.type === 'score') {
                    currentValue = score;
                } else if (subGoal.type === 'length') {
                    currentValue = snake.length;
                }
                
                combinedProgress += Math.min(currentValue, subGoal.target);
                combinedTarget += subGoal.target;
                
                const goalText = subGoal.type === 'score' ? '分' : '长度';
                progressText += `${currentValue}/${subGoal.target}${goalText} `;
            }
            
            levelProgress = (combinedProgress / combinedTarget) * goal.target;
            levelProgressElement.textContent = progressText;
        }
        
        // 更新进度条
        const progressPercentage = Math.min((levelProgress / (goal.target || 1)) * 100, 100);
        levelProgressBarElement.style.width = `${progressPercentage}%`;
        
        // 检查关卡是否完成
        checkLevelComplete();
    }

    // 检查关卡是否完成
    function checkLevelComplete() {
        const goal = levelGoals[currentLevel - 1];
        
        if (goal.type === 'combo') {
            // 组合目标检查
            const allCompleted = goal.targets.every(subGoal => {
                if (subGoal.type === 'score') {
                    return score >= subGoal.target;
                } else if (subGoal.type === 'length') {
                    return snake.length >= subGoal.target;
                }
                return false;
            });
            
            if (allCompleted) {
                completeLevel();
            }
        } else if (levelProgress >= goal.target) {
            // 普通目标检查
            completeLevel();
        }
    }

    // 完成关卡
    function completeLevel() {
        isGameOver = true;
        clearInterval(gameInterval);
        if (bossInterval) clearInterval(bossInterval);
        if (powerupInterval) clearInterval(powerupInterval);
        if (levelTimeInterval) clearInterval(levelTimeInterval);
        
        completedLevelElement.textContent = currentLevel;
        levelScoreElement.textContent = score;
        levelCompleteElement.classList.remove('hidden');
    }

    // 下一关
    function nextLevel() {
        currentLevel++;
        
        // 如果超过最大关卡，重置到第一关
        if (currentLevel > levelGoals.length) {
            currentLevel = 1;
        }
        
        levelTime = 0;
        score = 0;
        initGame('level');
    }

    // 键盘控制
    document.addEventListener('keydown', (e) => {
        // 防止方向键滚动页面
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
            e.preventDefault();
        }
        
        // 控制方向
        switch(e.key) {
            case 'ArrowUp':
                if (direction !== 'down') {
                    nextDirection = 'up';
                }
                break;
            case 'ArrowDown':
                if (direction !== 'up') {
                    nextDirection = 'down';
                }
                break;
            case 'ArrowLeft':
                if (direction !== 'right') {
                    nextDirection = 'left';
                }
                break;
            case 'ArrowRight':
                if (direction !== 'left') {
                    nextDirection = 'right';
                }
                break;
            case ' ': // 空格键暂停/继续
                togglePause();
                break;
            case 'r': // R键重新开始
                if (isGameOver) {
                    if (isLevelMode) {
                        initGame('level');
                    } else {
                        initGame();
                    }
                }
                break;
            case 'n': // N键下一关
                if (isLevelMode && levelCompleteElement.classList.contains('hidden') === false) {
                    nextLevel();
                }
                break;
        }
    });

    // 移动设备按钮控制
    upBtn.addEventListener('click', () => {
        if (direction !== 'down') {
            nextDirection = 'up';
        }
    });
    
    downBtn.addEventListener('click', () => {
        if (direction !== 'up') {
            nextDirection = 'down';
        }
    });
    
    leftBtn.addEventListener('click', () => {
        if (direction !== 'right') {
            nextDirection = 'left';
        }
    });
    
    rightBtn.addEventListener('click', () => {
        if (direction !== 'left') {
            nextDirection = 'right';
        }
    });

    // 模式切换
    classicModeTab.addEventListener('click', () => {
        if (!isGameOver) return;
        
        isLevelMode = false;
        classicModeTab.classList.remove('mode-tab-inactive');
        classicModeTab.classList.add('mode-tab-active');
        levelModeTab.classList.remove('mode-tab-active');
        levelModeTab.classList.add('mode-tab-inactive');
        classicModeInfo.classList.remove('hidden');
        levelModeInfo.classList.add('hidden');
    });
    
    levelModeTab.addEventListener('click', () => {
        if (!isGameOver) return;
        
        isLevelMode = true;
        levelModeTab.classList.remove('mode-tab-inactive');
        levelModeTab.classList.add('mode-tab-active');
        classicModeTab.classList.remove('mode-tab-active');
        classicModeTab.classList.add('mode-tab-inactive');
        levelModeInfo.classList.remove('hidden');
        classicModeInfo.classList.add('hidden');
        updateLevelDisplay();
    });

    // 按钮事件
    startBtn.addEventListener('click', () => {
        if (isGameOver) {
            initGame();
            startBtn.disabled = true;
            pauseBtn.disabled = false;
        }
    });
    
    pauseBtn.addEventListener('click', togglePause);
    
    restartBtn.addEventListener('click', () => {
        if (isLevelMode) {
            initGame('level');
        } else {
            initGame();
        }
        startBtn.disabled = isLevelMode ? false : true;
        pauseBtn.disabled = false;
        startLevelBtn.disabled = isLevelMode ? true : false;
    });
    
    startLevelBtn.addEventListener('click', () => {
        if (isGameOver) {
            initGame('level');
            startLevelBtn.disabled = true;
            pauseBtn.disabled = false;
        }
    });
    
    nextLevelBtn.addEventListener('click', nextLevel);
    
    restartLevelBtn.addEventListener('click', () => {
        initGame('level');
        startLevelBtn.disabled = true;
        pauseBtn.disabled = false;
    });

    // 初始绘制
    drawGame();
});    